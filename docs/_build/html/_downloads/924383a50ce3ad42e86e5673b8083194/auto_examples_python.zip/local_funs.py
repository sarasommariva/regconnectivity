"""
Example of local functions
===========================

Using functions without defining a package
"""


def ex_localfun(a, b):
    c = b - 2*a    
    print(c)


