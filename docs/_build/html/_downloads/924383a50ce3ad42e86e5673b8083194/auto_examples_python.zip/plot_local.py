"""
Title of the example
===========================

Short description
"""

# With setup.py I should be able to avoid to import the path
#import sys
#sys.path.insert(1, '../pypackage')
# import funs

import local_funs as lf

lf.ex_localfun(4, 20)
